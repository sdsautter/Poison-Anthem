document.getElementById("Sean").addEventListener("click", function () {
	document.getElementById("bandPic").src="pics/Sean.png";
;
	document.getElementById("caption").innerHTML = "Rhythm Guitarist: Sean Shotdown";
});

document.getElementById("Ashley").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Ashley.png";
	document.getElementById("caption").innerHTML = "Singer: Ashley Wynn";
});

document.getElementById("Larz").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Larz.png";
	document.getElementById("caption").innerHTML = "Bassist: Larz Robison";
});

document.getElementById("Manny").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Manny.png";
	document.getElementById("caption").innerHTML = "Drummer: Emmanuel Parial";
});

document.getElementById("Scott").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Scott.png";
	document.getElementById("caption").innerHTML = "Drummer: Scott Sautter";
});

document.getElementById("Jon").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Jon.png";
	document.getElementById("caption").innerHTML = "Lead Guitarist: Jon Evyl";
});

document.getElementById("Chris").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Chris.png";
	document.getElementById("caption").innerHTML = "Bassist: Chris Stolarczyk";
});

document.getElementById("Shawn").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Shawn.png";
	document.getElementById("caption").innerHTML = "Lead Guiatarist: Shawn Dickison";
});

document.getElementById("Danny").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Danny.png";
	document.getElementById("caption").innerHTML = "Bassist: Danny Sauer";
});

document.getElementById("Lee").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Lee.png";
	document.getElementById("caption").innerHTML = "Lead Guitarist: Lee DeVille";
});

document.getElementById("Lauren").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Lauren.png";
	document.getElementById("caption").innerHTML = "Singer: Lauren Bartlett";
});

document.getElementById("Jason").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Jason.png";
	document.getElementById("caption").innerHTML = "Bassist: Jason Graven";
});

document.getElementById("Jeremy").addEventListener("click", function() {
	document.getElementById("bandPic").src="pics/Jeremy.png";
	document.getElementById("caption").innerHTML = "Bassist: Jeremy Kelly";
});

document.getElementById("reset").addEventListener("click", function() {
		document.getElementById("bandPic").src="pics/Full Band.png";
		document.getElementById("caption").innerHTML ="From left to right: Lee DeVille, Scott Sautter, Jeremy Kelly, Sean Shotdown, and Lauren Bartlett";
});		

